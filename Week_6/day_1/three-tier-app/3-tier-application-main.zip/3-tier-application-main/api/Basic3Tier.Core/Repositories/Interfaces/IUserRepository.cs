﻿namespace Basic3Tier.Core;

public interface IUserRepository : ICommonRepository<User>
{
}
