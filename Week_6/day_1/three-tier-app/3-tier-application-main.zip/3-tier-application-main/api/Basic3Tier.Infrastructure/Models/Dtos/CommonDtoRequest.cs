﻿using Basic3Tier.Core;

namespace Basic3Tier.Infrastructure.Models;

public class CommonDtoRequest : Serializable
{
    public int Id { get; set; }
}
