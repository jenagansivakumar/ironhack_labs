﻿namespace Basic3Tier.Infrastructure.Models;

public class UserQueryParameters : QueryParameters
{
}
